package eshmun.modelchecker;

public enum ModelCheckerType {
	REGULAR,
	FAIR
}
