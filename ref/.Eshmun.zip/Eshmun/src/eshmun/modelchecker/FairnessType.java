package eshmun.modelchecker;

public enum FairnessType {
	WEAK_FAIRNESS,
	STRONG_FAIRNESS
}
