package eshmun.DecisionProcedure;

import java.awt.image.DataBufferByte;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Stack;

import eshmun.expression.PredicateFormula;
import eshmun.expression.atomic.bool.BooleanConstant;
import eshmun.expression.atomic.bool.BooleanPredicate;
import eshmun.expression.ctl.*;
import eshmun.expression.propoperator.*;

public class DecisionProcedure {

	private PredicateFormula _formula;
	
	public DecisionProcedure(PredicateFormula formula) {
		
		_formula = PredicateFormula.SendNegationToInside(formula);
	}
	public DecisionProcedure() {
		
	}
	
	public boolean CheckStatisfiability()
	{
		DPGraph graph =  generateTable();
		graph = optimizeTable(graph);
		boolean isSat = graph.hasStartState();
		return isSat;
	}
	
	public DPGraph generateTable()
	{
		DPGraph graph = new DPGraph();
		OrNode d0 = new OrNode("d0", _formula, true); 
		Stack<DPVertex> verticesToExplore = new Stack<DPVertex>();
		List<DPVertex> tempVertices = new ArrayList<DPVertex>();
		graph.AddOrNode(d0);
		int counter = 1;
		List<AndNode> generation1 = GenerateDBlocks(d0.getFormulas(), counter);
		counter += generation1.size(); 
		int count = 0;
		for (AndNode temp : generation1) {
			
			if(graph.ContainsAndNode(temp))
			{
				AndNode currentVertex = graph.AddAndNode(temp);
				graph.addEdge(d0, currentVertex);
				count++;
			}
			else
			{
				AndNode currentVertex = graph.AddAndNode(temp);
				graph.addEdge(d0, currentVertex);
				verticesToExplore.push(currentVertex);
			}
		}
		if(verticesToExplore.isEmpty())
			return graph;
		
		while(!verticesToExplore.isEmpty())
		{
			DPVertex current = verticesToExplore.pop();
			if(current instanceof OrNode)
			{
				List<AndNode> generation = GenerateDBlocks(current.getFormulas(), counter);
				counter += generation.size(); 
				int count1 = 0;
				for (AndNode temp : generation) {
					
					if(graph.ContainsAndNode(temp))
					{
						AndNode currentVertex = graph.AddAndNode(temp);
						graph.addEdge(current, currentVertex);
						count1++;
					}
					else
					{
						AndNode currentVertex = graph.AddAndNode(temp);
						graph.addEdge(current, currentVertex);
						tempVertices.add(currentVertex);
					}
				}
			}
			else if(current instanceof AndNode)
			{
				List<OrNode> generation = GenerateCTiles(current.getFormulas(), counter);
				counter += generation.size(); 
				int count2 = 0;
				for (OrNode temp : generation) {
					
					if(graph.ContainsOrNode(temp))
					{
						OrNode currentVertex = graph.AddOrNode(temp);
						graph.addEdge(current, currentVertex);
						count2++;
					}
					else
					{
						OrNode currentVertex = graph.AddOrNode(temp);
						graph.addEdge(current, currentVertex);
						tempVertices.add(currentVertex);
					}
				}
			}
			if(verticesToExplore.isEmpty())
			{
				verticesToExplore.addAll(tempVertices);
				tempVertices = new ArrayList<DPVertex>();
			}
		}
		
		
		return graph;
	}
	
	public DPGraph optimizeTable(DPGraph g)
	{
		boolean changed = true;
		while(changed)
		{
			boolean ch1 = DeleteP(g);
			boolean ch2 = DeleteOr(g);
			boolean ch3 = DeleteAND(g);
			boolean ch4 = DeleteEU(g);
			boolean ch5 = DeleteAU(g);
			boolean ch6 = DeleteEF(g);
			boolean ch7 = DeleteAF(g);
			if(!ch1 && !ch2 && !ch3 && !ch4 && !ch5 && !ch6 && !ch7)
				changed = false;				
		}
		return g;
	}
	
	public List<AndNode> GenerateDBlocks(List<PredicateFormula> frmls, int counter)
	{
		List<List<PredicateFormula>> DBlocks = new ArrayList<List<PredicateFormula>>();
		List<AndNode> andNodes = new ArrayList<AndNode>();
		Stack<List<PredicateFormula>> childrenStack = new Stack<List<PredicateFormula>>();
		childrenStack.add(frmls);
		
		while(!childrenStack.isEmpty())
		{
			List<PredicateFormula> stackFrmls = childrenStack.pop();
			List<PredicateFormula> returnToStack = new ArrayList<PredicateFormula>(stackFrmls);
			boolean listHasChanged = false;
			boolean enterToStack = false;
			for (PredicateFormula frml : stackFrmls) {
				if(isEligibleForAlphaExpansion(frml))
				{					
					returnToStack.remove(frml);
					returnToStack.addAll(AlphaExpansion(frml));
					listHasChanged = true;
					enterToStack = true;
				}
			}
			stackFrmls = new ArrayList<PredicateFormula>(returnToStack);			
			for (PredicateFormula frml : stackFrmls) {
				if(isEligibleForBetaExpansion(frml)){
					listHasChanged = true;
					enterToStack = false;
					List<PredicateFormula> betaTuple = BetaExpansion(frml);
					List<PredicateFormula> child1 = new ArrayList<PredicateFormula>(stackFrmls);
					List<PredicateFormula> child2 = new ArrayList<PredicateFormula>(stackFrmls);
					child1.add(betaTuple.get(0));
					child2.add(betaTuple.get(1));
					child1.remove(frml);
					child2.remove(frml);
					childrenStack.push(child1);
					childrenStack.push(child2);
					break;
				}
			}
			if(!listHasChanged)
			{
				DBlocks.add(returnToStack);
			}
			if(enterToStack)
			{
				childrenStack.push(returnToStack);
			}
		}
		for (List<PredicateFormula> list : DBlocks) {
			String nodeName = "C" + (++counter);
			AndNode temp = new AndNode(nodeName, list, false);
			andNodes.add(temp);
		}
		return andNodes;
	}
	
	private List<OrNode> GenerateCTiles(List<PredicateFormula> formulas, int counter)
	{
		List<List<PredicateFormula>> cTiles = new ArrayList<List<PredicateFormula>>();
		List<OrNode> orNodes = new ArrayList<OrNode>();
		List<PredicateFormula> AXs = new ArrayList<PredicateFormula>();
		List<PredicateFormula> EXs = new ArrayList<PredicateFormula>();
		for (PredicateFormula formula : formulas) {
			if(formula instanceof AXOperator)
			{
				AXs.add(((AXOperator) formula).getChild());
			}
			if(formula instanceof EXOperator)
			{
				EXs.add(((EXOperator) formula).getChild());
			}
		}
		if(EXs.size() == 0 && AXs.size() == 0)
		{
			String nodeName = "D" + (++counter);
			OrNode temp = new OrNode(nodeName, formulas, false);
			orNodes.add(temp);
			return orNodes;
		}
		if(EXs.size() == 0 )
		{
			BooleanPredicate trueChild = new BooleanPredicate(new BooleanConstant(true));
			EXOperator exOperator = new EXOperator(trueChild);
			EXs.add(exOperator);
		}
		for (PredicateFormula exFormula : EXs) {
			//be careful that here the same set will be referenced in all the ctiles
			//for now we see no bad effects for such
			List<PredicateFormula> cTile = new ArrayList<PredicateFormula>(AXs);
			cTile.add(exFormula);
			cTiles.add(cTile);
		}
		
		for (List<PredicateFormula> list : cTiles) {
			String nodeName = "D" + (++counter);
			OrNode temp = new OrNode(nodeName, list, false);
			orNodes.add(temp);
		}
		return orNodes;
	}	
	private List<PredicateFormula> AlphaExpansion(PredicateFormula formula) 
	{
		List<PredicateFormula> formulas = new ArrayList<PredicateFormula>();
		if(formula instanceof AndOperator)
		{
			formulas.add(((AndOperator) formula).getLeftChild());
			formulas.add(((AndOperator) formula).getRightChild());
		}
		//A[f V g] = g & ( f | AXA[f V g])
		else if(formula instanceof AVOperator)
		{
			formulas.add(((AVOperator) formula).getRightChild());
			//AXA[f V g]
			AXOperator ax = new AXOperator(formula);			
			OrOperator or = new OrOperator(((AVOperator) formula).getLeftChild(), ax);
			formulas.add(or);			
		}
		//E[f V g] = g & ( f | EXE[f V g])
		else if(formula instanceof EVOperator)
		{
			formulas.add(((EVOperator) formula).getRightChild());
			//EXE[f V g]
			EXOperator ex = new EXOperator(formula);			
			OrOperator or = new OrOperator(((EVOperator) formula).getLeftChild(), ex);
			formulas.add(or);	
		}
		//AG(g) = g & AXAG(g)
		else if(formula instanceof AGOperator)
		{
			formulas.add(((AGOperator) formula).getChild());
			AXOperator ax = new AXOperator(formula);
			formulas.add(ax);
		}
		//EG(g) = g & EXEG(g)
		else if(formula instanceof EGOperator)
		{
			formulas.add(((EGOperator) formula).getChild());
			EXOperator ex = new EXOperator(formula);
			formulas.add(ex);
		}
		return formulas;
	}
	private List<PredicateFormula> BetaExpansion(PredicateFormula formula) 
	{
		List<PredicateFormula> formulas = new ArrayList<PredicateFormula>();
		if(formula instanceof OrOperator)
		{
			formulas.add(((OrOperator) formula).getLeftChild());
			formulas.add(((OrOperator) formula).getRightChild());
		}
		//A[f U g] = g & ( f | AXA[f U g])
		else if(formula instanceof AUOperator)
		{
			formulas.add(((AUOperator) formula).getRightChild());
			//AXA[f U g]
			AXOperator ax = new AXOperator(formula);			
			OrOperator or = new OrOperator(((AUOperator) formula).getLeftChild(), ax);
			formulas.add(or);			
		}
		//E[f U g] = g & ( f | EXE[f U g])
		else if(formula instanceof EUOperator)
		{
			formulas.add(((EUOperator) formula).getRightChild());
			//EXE[f U g]
			EXOperator ex = new EXOperator(formula);			
			OrOperator or = new OrOperator(((EUOperator) formula).getLeftChild(), ex);
			formulas.add(or);	
		}
		//AF(g) = g & AXAF(g)
		else if(formula instanceof AGOperator)
		{
			formulas.add(((AFOperator) formula).getChild());
			AXOperator ax = new AXOperator(formula);
			formulas.add(ax);
		}
		//EF(g) = g & EXEF(g)
		else if(formula instanceof EFOperator)
		{
			formulas.add(((EFOperator) formula).getChild());
			EXOperator ex = new EXOperator(formula);
			formulas.add(ex);
		}
		return formulas;
	}
	private PredicateFormula GetNextTime(PredicateFormula formula) 
	{
		if(formula instanceof AXOperator)
		{
			return ((AXOperator) formula).getChild();
		}
		else if(formula instanceof EXOperator)
		{
			return ((EXOperator) formula).getChild();
		}
		return formula;
	}	

	private boolean isEligibleForAlphaExpansion(PredicateFormula formula)
	{
		if((formula instanceof AndOperator) || (formula instanceof AVOperator) ||
				(formula instanceof EVOperator) || (formula instanceof AGOperator) ||
				(formula instanceof EGOperator))
		{
			return true;
		}
			return false;
	}
	
	private boolean isEligibleForBetaExpansion(PredicateFormula formula)
	{
		if((formula instanceof OrOperator) || (formula instanceof AUOperator) ||
				(formula instanceof EUOperator) || (formula instanceof AFOperator) ||
				(formula instanceof EFOperator))
		{
			return true;
		}
		return false;
	}
	
	private boolean isNextTime(PredicateFormula formula)
	{
		return false;
	}
	
	/*
	 * Compute power set
	 */
	public static <T> Set<Set<T>> powerSet(Set<T> originalSet) {
	    Set<Set<T>> sets = new HashSet<Set<T>>();
	    if (originalSet.isEmpty()) {
	    	sets.add(new HashSet<T>());
	    	return sets;
	    }
	    List<T> list = new ArrayList<T>(originalSet);
	    T head = list.get(0);
	    Set<T> rest = new HashSet<T>(list.subList(1, list.size())); 
	    for (Set<T> set : powerSet(rest)) {
	    	Set<T> newSet = new HashSet<T>();
	    	newSet.add(head);
	    	newSet.addAll(set);
	    	sets.add(newSet);
	    	sets.add(set);
	    }		
	    return sets;
	}
	
	
	private boolean DeleteP(DPGraph graph)
	{
		 List<AndNode> andNodes =  new ArrayList<AndNode>(graph.getAndNodes());
		 List<OrNode> orNodes = new ArrayList<OrNode>(graph.getOrNodes());
		 boolean changed = false;
		for (AndNode and : andNodes) {
			if(and.isInconsistent())
			{
				graph.DeleteNode(and);
				changed = true;
			}
		}
		for (OrNode or : orNodes) {
			if(or.isInconsistent())
			{
				graph.DeleteNode(or);
				changed = true;
			}
		}
		return changed;
	}
	private boolean DeleteOr(DPGraph graph)
	{
		List<OrNode> orNodes = new ArrayList<OrNode>(graph.getOrNodes());
		boolean changed = false;
		for (OrNode or : orNodes) {
			if(!or.hasChildren())
			{
				graph.DeleteNode(or);
				changed = true;
			}
		}
		return changed;
	}
	
	private boolean DeleteAND(DPGraph graph)
	{
		List<AndNode> andNodes =  new ArrayList<AndNode>(graph.getAndNodes());
		boolean changed = false;
		for (AndNode and : andNodes) {
			if(and.isToBeDeleted())
			{
				graph.DeleteNode(and);
				changed = true;
			}
		}	
		return changed;
	}
	
	private boolean DeleteEU(DPGraph graph)
	{
		List<AndNode> andNodes =  new ArrayList<AndNode>(graph.getAndNodes());
		List<OrNode> orNodes = new ArrayList<OrNode>(graph.getOrNodes());
		boolean changed = false;
		for (AndNode and : andNodes) {
			EUOperator euOp = and.containsEU();
			if( euOp != null && !graph.CheckEU(and, euOp.getLeftChild(), euOp.getRightChild()))
			{
				graph.DeleteNode(and);
				changed = true;
			}
		}
		for (OrNode or : orNodes) {
			EUOperator euOp = or.containsEU();
			if( euOp != null && !graph.CheckEU(or, euOp.getLeftChild(), euOp.getRightChild()))
			{
				graph.DeleteNode(or);
				changed = true;
			}
		}
		return changed;
	}
	
	private boolean DeleteAU(DPGraph graph)
	{
		List<AndNode> andNodes =  new ArrayList<AndNode>(graph.getAndNodes());
		List<OrNode> orNodes = new ArrayList<OrNode>(graph.getOrNodes());
		boolean changed = false;
		for (AndNode and : andNodes) {
			AUOperator auOp = and.containsAU();
			if( auOp != null && !graph.CheckAU(and, auOp.getLeftChild(), auOp.getRightChild()))
			{
				graph.DeleteNode(and);
				changed = true;
			}
		}
		for (OrNode or : orNodes) {
			AUOperator auOp = or.containsAU();
			if( auOp != null && !graph.CheckAU(or, auOp.getLeftChild(), auOp.getRightChild()))
			{
				graph.DeleteNode(or);
				changed = true;
			}
		}
		return changed;
	}
	
	private boolean DeleteEF(DPGraph graph)
	{
		List<AndNode> andNodes =  new ArrayList<AndNode>(graph.getAndNodes());
		List<OrNode> orNodes = new ArrayList<OrNode>(graph.getOrNodes());
		boolean changed = false;
		for (AndNode and : andNodes) {
			EFOperator efOp = and.containsEF();
			if(efOp != null && !graph.CheckEF(and, efOp.getChild()))
			{
				graph.DeleteNode(and);
				changed = true;
			}
		}
		for (OrNode or : orNodes) {
			EFOperator efOp = or.containsEF();
			if(efOp != null && !graph.CheckEF(or, efOp.getChild()))
			{
				graph.DeleteNode(or);
				changed = true;
			}
		}
		return changed;
	}
	
	private boolean DeleteAF(DPGraph graph)
	{
		List<AndNode> andNodes =  new ArrayList<AndNode>(graph.getAndNodes());
		List<OrNode> orNodes = new ArrayList<OrNode>(graph.getOrNodes());
		boolean changed = false;
		for (AndNode and : andNodes) {
			AFOperator afOp = and.containsAF();
			if( afOp != null && !graph.CheckAF(and, afOp.getChild()))
			{
				graph.DeleteNode(and);
				changed = true;
			}
		}
		for (OrNode or : orNodes) {
			AFOperator afOp = or.containsAF();
			if( afOp != null && !graph.CheckAF(or, afOp.getChild()))
			{
				graph.DeleteNode(or);
				changed = true;
			}
		}
		return changed;
	}
	
	
}
