package eshmun.DecisionProcedure;

import java.util.List;

import eshmun.expression.PredicateFormula;

public class OrNode extends DPVertex {

	public OrNode(String name, List<PredicateFormula> formulas, boolean isStartState) {
		super(name, formulas, isStartState);
	}

	public OrNode(String name, PredicateFormula formula, boolean isStartState) {
		super(name, formula, isStartState);
	}

}
