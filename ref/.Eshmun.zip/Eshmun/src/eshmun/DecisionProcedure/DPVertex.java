package eshmun.DecisionProcedure;

import java.util.ArrayList;
import java.util.List;

import eshmun.expression.PredicateFormula;
import eshmun.expression.atomic.bool.BooleanPredicate;
import eshmun.expression.ctl.AFOperator;
import eshmun.expression.ctl.AUOperator;
import eshmun.expression.ctl.EFOperator;
import eshmun.expression.ctl.EUOperator;

public class DPVertex {
	
	
	private String _name ;
	private List<PredicateFormula> _formulas;
	private List<DPEdge> _edges;
	private List<DPEdge> _incomingEdges;
	private boolean _isStartState;
	
	
	
	public List<DPEdge> getEdges() {
		return _edges;
	}




	public List<DPEdge> getIncomingEdges() {
		return _incomingEdges;
	}
	
	public void RemoveIncomingEdge(DPEdge edge)
	{
		_incomingEdges.remove(edge);
	}
	public void RemoveOutcomingEdge(DPEdge edge)
	{
		_edges.remove(edge);
	}

	public boolean hasChildren()
	{
		return _edges.size() > 0;
	}


	public String getName() {
		return _name;
	}


	

	public List<PredicateFormula> getFormulas() {
		return _formulas;
	}

	public void setFormulas(List<PredicateFormula> _formulas) {
		this._formulas = _formulas;
	}

	public DPVertex(String name, List<PredicateFormula> formulas, boolean isStartState) {
		_name = name;
		_formulas = formulas;
		_edges = new ArrayList<DPEdge>();
		_incomingEdges = new ArrayList<DPEdge>();
		_isStartState = isStartState;
	}
	
	public DPVertex(String name, PredicateFormula formula, boolean isStartState) {
		_name = name;
		List<PredicateFormula> formulas = new ArrayList<PredicateFormula>();
		formulas.add(formula);
		_formulas = formulas;
		_edges = new ArrayList<DPEdge>();
		_incomingEdges = new ArrayList<DPEdge>();
		_isStartState = isStartState;
	}
	
	
	public boolean isStartState() {
		return _isStartState;
	}




	protected void AddEdge(DPEdge edge)
	{
		if(edge.getvFrom().equals(this)){
			_edges.add(edge);
		}
	}
	protected void AddIncomingEdge(DPEdge edge)
	{
		if(edge.getvTo().equals(this)){
			_incomingEdges.add(edge);
		}
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((_formulas == null) ? 0 : _formulas.hashCode());
		return result;
	}
	
	
	
	public boolean ContainsFormula(PredicateFormula pred)
	{
		for (PredicateFormula frml : _formulas) {
				if(frml.toString().equals(pred.toString()))
					return true;
		}
		return false;
	}

/*
 * 2 VERTEX ARE EQUAL IF THEY HAVE THE SAME SET OF FORMULAS
 * @see java.lang.Object#equals(java.lang.Object)
 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DPVertex other = (DPVertex) obj;
		if (_formulas == null) {
			if (other._formulas != null)
				return false;
		} else if (!_formulas.equals(other._formulas))
			return false;
		return true;
	}
	
	
	public boolean isInconsistent()
	{
		List<PredicateFormula> frmls = new ArrayList<PredicateFormula>(_formulas);
		for (PredicateFormula frml : frmls) {
			for (PredicateFormula innerfrml : frmls) {
				if(!frml.equals(innerfrml) && frml.isMyNegation(innerfrml))
					return true;
			}
		}
		return false;
	}
	
	public EUOperator containsEU()
	{
		for (PredicateFormula frml : _formulas) {
			if(frml instanceof EUOperator)
				return (EUOperator)frml;
		}
		return null;
	}
	
	public AUOperator containsAU()
	{
		for (PredicateFormula frml : _formulas) {
			if(frml instanceof AUOperator)
				return (AUOperator)frml;
		}
		return null;
	}
	
	public EFOperator containsEF()
	{
		for (PredicateFormula frml : _formulas) {
			if(frml instanceof EFOperator)
				return (EFOperator)frml;
		}
		return null;
	}
	
	public AFOperator containsAF()
	{
		for (PredicateFormula frml : _formulas) {
			if(frml instanceof AFOperator)
				return (AFOperator)frml;
		}
		return null;
	}


}
