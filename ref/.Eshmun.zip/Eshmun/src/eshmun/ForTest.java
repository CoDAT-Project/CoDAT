package eshmun;

import java.io.IOException;

import java.awt.font.TextAttribute;
import java.text.AttributedString;
import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Random;

import eshmun.expression.PredicateFormula;
import eshmun.expression.PredicateFormulaValuation;
import eshmun.expression.atomic.bool.BooleanPredicate;
import eshmun.expression.atomic.bool.BooleanVariable;
import eshmun.expression.ctl.AGOperator;
import eshmun.expression.ctl.EFOperator;
import eshmun.expression.propoperator.AndOperator;
import eshmun.expression.propoperator.NotOperator;
import eshmun.expression.propoperator.OrOperator;
import eshmun.lts.kripke.Kripke;
import eshmun.lts.kripke.KripkeState;
import eshmun.lts.kripke.Transition;
import eshmun.modelrepairer.FormulaStringCollection;
import eshmun.parser.ANTLRParser;
import eshmun.parser.antlr.lexer.SpecLexer;
import eshmun.parser.antlr.parser.SpecParserAST;
import eshmun.sat.CNFFile;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.antlr.runtime.ANTLRStringStream;
import org.antlr.runtime.CharStream;
import org.antlr.runtime.CommonTokenStream;
import org.sat4j.minisat.*;
import org.sat4j.reader.DimacsReader;
import org.sat4j.reader.ParseFormatException;
import org.sat4j.reader.Reader;
import org.sat4j.specs.*;
import java.util.*;
import java.io.*;
import eshmun.DecisionProcedure.*;

public class ForTest {
	
	public static void main(String[] args) throws IOException {
		System.out.println(CheckSatisfiability());
		/*List<PredicateFormula> list = new ArrayList<PredicateFormula>();
		
		BooleanPredicate p = new BooleanPredicate("p");
		NotOperator notP = new NotOperator(p);
		EFOperator efP = new EFOperator(p);
		AGOperator efNotP = new AGOperator(notP);
		//EFOperator efNotP = new EFOperator(notP);
		AndOperator and = new AndOperator(efP, efNotP);
		list.add(and);
		DecisionProcedure  proc = new DecisionProcedure(and);
		DPGraph graph =  proc.generateTable();
		graph = proc.optimizeTable(graph);
		List<AndNode> dBlocks = graph.getAndNodes();
		List<OrNode> cTyles = graph.getOrNodes();
		boolean isSat = false;
		for (OrNode orNode : cTyles) {
			if(orNode.isStartState())
				isSat = true;
		}
		
		if(isSat)
			System.out.println("staisfiable");
		else			
			System.out.println("not staisfiable");
		//dBlocks = proc.GenerateDBlocks(list);
		for (AndNode andNode : dBlocks) {		
			System.out.println(andNode.getName());
			for (PredicateFormula predicateFormula : andNode.getFormulas()) {
				System.out.println(predicateFormula.toString());
			}
		
		}
		for (OrNode orNode : cTyles) {		
			System.out.println(orNode.getName());
			for (PredicateFormula predicateFormula : orNode.getFormulas()) {
				System.out.println(predicateFormula.toString());
			}
		
		}
		List<DPEdge> edges = graph.getEdges();
		for(DPEdge edge : edges)
		{
			System.out.println(edge.getvFrom().getName() + "-->" + edge.getvTo().getName());
		}*/
		
		
	}

	/*public static void main(String[] args) throws IOException {
		
		//System.out.println(CheckSatisfiability());
		
		ANTLRParser parser = new ANTLRParser();
		PredicateFormula pf = null;
		try {
			
			CharStream input = new ANTLRStringStream("s=>t");
			SpecLexer lexer = new SpecLexer(input);
			CommonTokenStream tokens = new CommonTokenStream(lexer);
			Dictionary tokenDictionary = getTokensDictionary("C:\\SpecLexer.tokens");
			int counter = 1;
			while(tokens.LA(counter) != -1)
			{
				String tokenName = (String)tokenDictionary.get(Integer.toString(tokens.LA(counter)));
				tokenName += "   Line number: " + tokens.LT(counter).getLine();
				System.out.print(tokens.LT(counter).getText() + ": ");
				System.out.println(tokenName);
				counter ++;
			}
			//pf = parser.parse("(!(x) | ( (!(y) | z) & (!(s) | t) ) )&( !( (!(y) | z) & (!(s) | t) ) | x)");
			//pf = parser.parse("x | ((y & z) | (s & t))");
			SpecParserAST parsert = new SpecParserAST(tokens);
			SpecParserAST.ctl_formula_return root = parsert.ctl_formula();
			pf = parser.parse("A[G(s|t)]");
			//pf = parser.parse("x | (y | z)");
			//pf = parser.parse("A[(p) U (q)]");
			//pf = parser.parse("A[(p&q) U (c&d)]");
			//pf = parser.parse("(A[(p&q) U (c&d)] | t)");
			//pf = parser.parse("(p&d)");
			List<PredicateFormula> list = new ArrayList<PredicateFormula>();
			pf.GetNotCTLSubFormulae(list, pf, false);
			KripkeState st = new KripkeState(null, "test", false);
			BooleanPredicate pred1 = new BooleanPredicate(new BooleanVariable("p"));
			BooleanPredicate pred2 = new BooleanPredicate(new BooleanVariable("q"));
			PredicateFormulaValuation predValu1 = new PredicateFormulaValuation(
					null, st, pred1, true);
			PredicateFormulaValuation predValu2 = new PredicateFormulaValuation(
					null, st, pred2, true);
			st.addPredicateFormulaValuation(predValu1);
			st.addPredicateFormulaValuation(predValu2);
			System.out.println(list.get(0).isSatisfiedBy(st));
			for (PredicateFormula predicateFormula : list) {
				System.out.println(predicateFormula.toString());
			}
			
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//char c =  00B2;
		//System.out.println((char)c);
		//System.out.println("X\u00B2\u00B2");
		//System.out.println("\u2074");
		//System.in.read();
//		Random random = new  Random();
//		System.out.println(pf.toString());
//		PredicateFormula pf1 = pf.ConvertToCNF(pf, random );
//		System.out.println(pf1.toString());

//		List<PredicateFormula> list = pf.getSubFormulea();
//		for (PredicateFormula predicateFormula : list) {
//			System.out.println(predicateFormula.toString());
//		}
//		
		// TODO Auto-generated method stub

	}*/
	private static Dictionary getTokensDictionary(String filePath)  throws Exception 
	{
		Scanner scan = new Scanner(new File(filePath));
		Dictionary tokenDictionary = new Hashtable<String, String>();
		while(scan.hasNext())
            {
                String[] tokenclass = new String[2];
				tokenclass = (scan.nextLine()).split("=");
                tokenDictionary.put(tokenclass[1], tokenclass[0]);
            }
		return tokenDictionary;
	}
	
	private static List<OrOperator> ConvertToListofORs(PredicateFormula CNFFormula)
	{
		List<OrOperator> orOps = new ArrayList<OrOperator>();
		PriorityQueue<PredicateFormula> q = new PriorityQueue<PredicateFormula>();  
		q.add(CNFFormula);
		while(!q.isEmpty())
		{
			PredicateFormula formula = (PredicateFormula)q.poll();
			if(formula.getClass().equals(AndOperator.class))///AND/////AND/////AND/////AND/////AND/////AND//
			{
				AndOperator andOp = (AndOperator) formula;
				q.add(andOp.getLeftChild());
				PredicateFormula ff = andOp.getRightChild();
				q.add(ff);
			}
			else if(formula.getClass().equals(OrOperator.class))
			{
				orOps.add((OrOperator)formula);
			}
		}
		return orOps;
	}
	private static String CheckSatisfiability()
	{
		StringBuilder result = new StringBuilder();
		
		ISolver solver = SolverFactory.newDefault ();
		solver . setTimeout (3600); // 1 hour timeout
		Reader reader = new DimacsReader ( solver );
		
		try {
		IProblem problem = reader.parseInstance ("CNFFile.cnf");
		if ( problem.isSatisfiable ()) {
			result.append(" Satisfiable  ! \n");
			result.append(reader.decode(problem.model()));
			return result.toString();
		} else {
			result.append(" Unsatisfiable  !");
			return result.toString();
		}
		} catch ( FileNotFoundException e) {
			result.append(e.getMessage());
			return result.toString();
		} catch ( ParseFormatException e) {
			result.append(e.getMessage());
			return result.toString();
		} catch ( IOException e) {
			result.append(e.getMessage());
			return result.toString();
		} catch ( ContradictionException e) {
			result.append(" Unsatisfiable  ( trivial )!");
			 return result.toString();
		} catch ( TimeoutException e) {
			result.append(" Timeout ,  sorry !");
			return result.toString();
		}
	}

}
