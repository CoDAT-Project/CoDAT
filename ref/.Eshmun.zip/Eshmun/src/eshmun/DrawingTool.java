package eshmun;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.io.File;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;

import eshmun.lts.kripke.Kripke;
import eshmun.lts.kripke.Transition;

public class DrawingTool {

	public DrawingTool() {
		
	}
	
public String DoDrawDiagram(Kripke kripke, Collection<Transition> transitions) {
		
		CreateKripkeFile(kripke, transitions);
		long refresh = System.currentTimeMillis();

		 // create new filename filter
		File f = null;
        FilenameFilter fileNameFilter = new FilenameFilter() {
  
           @Override
           public boolean accept(File dir, String name) {
              if(name.lastIndexOf('.')>0)
              {
                 // get last index for '.' char
                 int lastIndex = name.lastIndexOf('.');
                 
                 // get extension
                 String str = name.substring(lastIndex);
                 
                 // match path name extension
                 if(str.equals(".png") && name.startsWith("output"))
                 {
                    return true;
                 }
              }
              return false;
           }
        };
        // returns pathnames for files and directory
        f = new File(".\\dottool");
        File[] paths = f.listFiles(fileNameFilter);
        //for(File path:paths)
        //{
        //   path.delete();
        //}
		String command = "cmd /c dot -Tpng dottool\\kripke.dot -o dottool\\output" + refresh + ".png";
        //String command = "dottool/dot.exe -Tpng dottool\\kripke.dot -o dottool\\output" + refresh + ".png";
		try {
			Process p = Runtime.getRuntime().exec(command);
			p.waitFor();
			if (p.exitValue() == 0) {
				return "dottool\\output" + refresh + ".png";	
			}

		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		} catch (InterruptedException e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
		return "";
	}
	
	private void CreateKripkeFile(Kripke kripke, Collection<Transition> transitions)
	{
		try {
			
			File dotFile = new File("dottool\\kripke.dot");
			if (dotFile.exists())
				dotFile.delete();
			dotFile.createNewFile();
			FileWriter fw = new FileWriter(dotFile);
			PrintWriter pw = new PrintWriter(fw);
			String[] stmts;
			if(transitions != null)
				stmts = kripke.GenerateDotText(transitions);
			else
				stmts = kripke.GenerateDotText();
			for (String str : stmts) {
				pw.println(str);
			}
			pw.flush();
			fw.flush();

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}


}
